const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000;
const ADMIN = process.env.ADMIN_PASSWORD || 'admin123'; // ПОМЕНЯЙ через переменную ADMIN_PASSWORD
const DB_FILE = path.join(__dirname, 'data.json');
let db = { users: {}, msgs: [], groups: [], sessions: {}, nextId: 1, uid: 1000, gifts: [], sold: {} };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE))); } catch {}
for (const u of Object.values(db.users)) { if (!u.id) u.id = ++db.uid; if (typeof u.stars !== 'number') u.stars = 0; if (!u.hist) u.hist = []; if (!u.badge) u.badge = '💎'; if (u.title === undefined) u.title = ''; if (u.bio === undefined) u.bio = ''; }
let timer;
const save = () => { clearTimeout(timer); timer = setTimeout(() => fs.writeFile(DB_FILE, JSON.stringify(db), () => {}), 500); };
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString('hex');
const json = (res, c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const body = req => new Promise(r => { let b = ''; req.on('data', d => { b += d; if (b.length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const NAME = /^[a-zA-Z0-9_]{3,20}$/;
const files = { '/': 'index.html', '/admin': 'admin.html', '/manifest.json': 'manifest.json', '/sw.js': 'sw.js', '/icon-192.png': 'icon-192.png', '/icon-512.png': 'icon-512.png' };
const types = { '.json': 'application/json', '.js': 'text/javascript', '.png': 'image/png', '.html': 'text/html; charset=utf-8' };
const online = new Map(); // ws -> name
const codes = Object.create(null);
const BADGES = ['💎', '⭐', '🔥', '👑', '🦄', '🚀', '🌈'];
// s = лимитированный тираж (коллекционный подарок с серийным номером)
const GIFTS = {
  heart: { n: 'Сердце', e: '❤️', p: 30 }, bear: { n: 'Мишка', e: '🧸', p: 50 }, cake: { n: 'Торт', e: '🎂', p: 80 }, rocket: { n: 'Ракета', e: '🚀', p: 100 },
  crown: { n: 'Корона', e: '👑', p: 500, s: 100 }, diamond: { n: 'Алмаз', e: '💎', p: 1000, s: 50 }, unicorn: { n: 'Единорог', e: '🦄', p: 2000, s: 20 }
};
const profile = n => {
  const u = db.users[n], ph = u.phone || '';
  return { name: n, id: u.id, title: u.title, bio: u.bio, badge: u.badge, anon: !!u.anon, created: u.created,
    phone: u.anon ? ph : (ph ? ph.slice(0, -4).replace(/\d/g, '•') + ph.slice(-4) : ''),
    gifts: db.gifts.filter(g => g.owner === n).slice(-60).map(g => ({ serial: g.serial, from: g.from, e: GIFTS[g.gid].e, n: GIFTS[g.gid].n })) };
};
const send = (ws, o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
const broadcast = o => { for (const w of online.keys()) send(w, o); };
const canSee = (chat, name) => chat === 'general' || db.groups.some(g => g.id === chat) ||
  (typeof chat === 'string' && chat.startsWith('dm:') && chat.slice(3).split('|').includes(name));
const wallet = n => ({ t: 'wallet', stars: db.users[n].stars, hist: db.users[n].hist });
const pushWallet = n => { for (const [w, x] of online) if (x === n) send(w, wallet(n)); };
const addHist = (usr, amount, from) => { usr.hist.unshift({ amount, from, ts: Date.now() }); usr.hist.length = Math.min(usr.hist.length, 50); };
const kick = name => { for (const [w, n] of online) if (n === name) { send(w, { t: 'kick' }); w.close(); } };

const server = http.createServer(async (req, res) => {
  const u = req.url.split('?')[0];
  if (req.method === 'GET' && files[u]) {
    const f = path.join(__dirname, files[u]);
    res.writeHead(200, { 'Content-Type': types[path.extname(f)] || 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(f));
  }
  if (u.startsWith('/api/admin/')) {
    if (req.headers['x-admin'] !== ADMIN) return json(res, 401, { error: 'Неверный пароль админа' });
    if (u === '/api/admin/stats') return json(res, 200, { users: Object.keys(db.users).length, msgs: db.msgs.length, groups: db.groups.length, online: new Set(online.values()).size });
    if (u === '/api/admin/users') return json(res, 200, Object.entries(db.users).map(([name, x]) => ({ name, id: x.id, stars: x.stars, created: x.created, banned: x.banned, online: [...online.values()].includes(name) })));
    if (u === '/api/admin/msgs') return json(res, 200, db.msgs.slice(-100).reverse());
    if (u === '/api/admin/ban') { const { name, banned } = await body(req); if (!db.users[name]) return json(res, 404, {}); db.users[name].banned = !!banned; save(); if (banned) kick(name); return json(res, 200, { ok: 1 }); }
    if (u === '/api/admin/delmsg') { const { id } = await body(req); db.msgs = db.msgs.filter(m => m.id !== id); save(); broadcast({ t: 'del', id }); return json(res, 200, { ok: 1 }); }
    if (u === '/api/admin/stars') {
      const { who, amount } = await body(req);
      const n = Math.trunc(Number(amount)), w = String(who).trim();
      const key = Object.keys(db.users).find(k => k === w || String(db.users[k].id) === w);
      if (!key || !Number.isFinite(n) || n === 0 || Math.abs(n) > 1e9) return json(res, 400, { error: 'bad' });
      const usr = db.users[key];
      usr.stars = Math.max(0, usr.stars + n);
      addHist(usr, n, 'Админ'); save(); pushWallet(key);
      return json(res, 200, { name: key, stars: usr.stars });
    }
    return json(res, 404, {});
  }
  if (req.method === 'POST' && u === '/api/anon') {
    let ph; do { ph = '+888' + Math.floor(1e7 + Math.random() * 9e7); } while (Object.values(db.users).some(x => x.phone === ph));
    return json(res, 200, { phone: ph });
  }
  if (req.method === 'POST' && u === '/api/sendcode') {
    const { phone } = await body(req); const ph = String(phone || '').replace(/[\s()-]/g, '');
    if (!/^\+?\d{7,15}$/.test(ph)) return json(res, 400, { error: 'Неверный номер' });
    const code = String(Math.floor(10000 + Math.random() * 90000));
    codes[ph] = { code, exp: Date.now() + 5 * 60e3 };
    console.log('CODE for', ph, code);
    return json(res, 200, { phone: ph, code }); // демо: SMS-провайдера нет, код показываем на экране
  }
  if (req.method === 'POST' && u === '/api/verify') {
    const { phone, code, name } = await body(req); const c = codes[phone];
    if (!c || c.exp < Date.now() || c.code !== String(code).trim()) return json(res, 401, { error: 'Неверный код' });
    let key = Object.keys(db.users).find(k => db.users[k].phone === phone);
    if (!key) {
      if (!name) return json(res, 200, { needName: true });
      if (!NAME.test(name) || db.users[name]) return json(res, 400, { error: 'Имя занято или неверное (a-z, 0-9, _, 3-20)' });
      key = name;
      db.users[key] = { created: Date.now(), banned: false, id: ++db.uid, stars: 0, hist: [], badge: '💎', title: '', bio: '', phone, anon: phone.startsWith('+888') };
      broadcast({ t: 'user', user: { name: key, id: db.users[key].id, badge: '💎', title: '' } });
    }
    if (db.users[key].banned) return json(res, 403, { error: 'Аккаунт заблокирован' });
    delete codes[phone];
    const token = crypto.randomBytes(24).toString('hex'); db.sessions[token] = key; save();
    return json(res, 200, { token, name: key });
  }
  if (req.method === 'POST' && (u === '/api/register' || u === '/api/login')) {
    const { name, pass } = await body(req);
    if (!NAME.test(name || '') || typeof pass !== 'string' || pass.length < 6) return json(res, 400, { error: 'Имя: 3-20 символов (a-z, 0-9, _). Пароль: от 6' });
    if (u === '/api/register') {
      if (db.users[name]) return json(res, 400, { error: 'Имя занято' });
      const salt = crypto.randomBytes(8).toString('hex');
      db.users[name] = { salt, hash: hash(pass, salt), created: Date.now(), banned: false, id: ++db.uid, stars: 0, hist: [], badge: '💎', title: '', bio: '' };
      save(); broadcast({ t: 'user', user: { name, id: db.users[name].id, badge: '💎', title: '' } });
    }
    const usr = db.users[name];
    if (!usr || !usr.hash || usr.hash !== hash(pass, usr.salt)) return json(res, 401, { error: 'Неверное имя или пароль' });
    if (usr.banned) return json(res, 403, { error: 'Аккаунт заблокирован' });
    const token = crypto.randomBytes(24).toString('hex');
    db.sessions[token] = name; save();
    return json(res, 200, { token, name });
  }
  json(res, 404, { error: 'not found' });
});

const wss = new WebSocketServer({ server });
wss.on('connection', ws => {
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'auth') {
      const n = db.sessions[m.token], usr = db.users[n];
      if (!usr || usr.banned) { send(ws, { t: 'kick' }); return ws.close(); }
      online.set(ws, n);
      send(ws, { t: 'init', me: n, id: usr.id, groups: db.groups, users: Object.entries(db.users).map(([name, x]) => ({ name, id: x.id, badge: x.badge, title: x.title })), gifts: GIFTS, badges: BADGES });
      return send(ws, wallet(n));
    }
    const me = online.get(ws);
    if (!me) return;
    if (db.users[me].banned) { send(ws, { t: 'kick' }); return ws.close(); }
    if (m.t === 'hist' && canSee(m.chat, me)) return send(ws, { t: 'hist', chat: m.chat, msgs: db.msgs.filter(x => x.chat === m.chat).slice(-50) });
    if (m.t === 'msg' && canSee(m.chat, me) && typeof m.text === 'string' && m.text.trim()) {
      const msg = { id: db.nextId++, chat: m.chat, from: me, text: m.text.slice(0, 2000), ts: Date.now() };
      db.msgs.push(msg); if (db.msgs.length > 5000) db.msgs.shift(); save();
      for (const [w, n] of online) if (canSee(m.chat, n)) send(w, { t: 'msg', msg });
    }
    if (m.t === 'send') {
      const n = Math.trunc(Number(m.amount)), from = db.users[me];
      if (!Object.hasOwn(db.users, m.to) || m.to === me || !Number.isFinite(n) || n <= 0 || n > from.stars) return send(ws, { t: 'err', text: 'Нельзя отправить: проверь имя и сумму' });
      from.stars -= n; db.users[m.to].stars += n;
      addHist(from, -n, 'Кому: ' + m.to); addHist(db.users[m.to], n, 'От: ' + me);
      save(); pushWallet(me); pushWallet(m.to);
    }
    if (m.t === 'profile' && Object.hasOwn(db.users, m.name)) return send(ws, { t: 'profile', p: profile(m.name) });
    if (m.t === 'setprofile') {
      const u = db.users[me];
      if (typeof m.title === 'string') u.title = m.title.trim().slice(0, 30);
      if (typeof m.bio === 'string') u.bio = m.bio.trim().slice(0, 140);
      if (BADGES.includes(m.badge)) u.badge = m.badge;
      save(); broadcast({ t: 'user', user: { name: me, id: u.id, badge: u.badge, title: u.title } });
      return send(ws, { t: 'profile', p: profile(me) });
    }
    if (m.t === 'gift') {
      const g = Object.hasOwn(GIFTS, m.gid) ? GIFTS[m.gid] : null, from = db.users[me];
      if (!g || !Object.hasOwn(db.users, m.to) || m.to === me) return send(ws, { t: 'err', text: 'Выбери подарок и получателя' });
      if (g.s && (db.sold[m.gid] || 0) >= g.s) return send(ws, { t: 'err', text: 'Этот подарок закончился' });
      if (from.stars < g.p) return send(ws, { t: 'err', text: 'Не хватает звёзд' });
      from.stars -= g.p; addHist(from, -g.p, 'Подарок для ' + m.to);
      const serial = g.s ? (db.sold[m.gid] = (db.sold[m.gid] || 0) + 1) : 0;
      db.gifts.push({ id: db.nextId++, gid: m.gid, serial, owner: m.to, from: me, ts: Date.now() });
      const chat = 'dm:' + [me, m.to].sort().join('|');
      const msg = { id: db.nextId++, chat, from: me, text: '', gift: { e: g.e, n: g.n, serial, of: g.s || 0 }, ts: Date.now() };
      db.msgs.push(msg); save(); pushWallet(me);
      for (const [w, n] of online) if (n === me || n === m.to) send(w, { t: 'msg', msg });
      return;
    }
    if (m.t === 'newgroup' && typeof m.name === 'string' && m.name.trim()) {
      const g = { id: 'g:' + db.nextId++, name: m.name.trim().slice(0, 30), owner: me };
      db.groups.push(g); save(); broadcast({ t: 'group', g });
    }
  });
  ws.on('close', () => online.delete(ws));
});
server.listen(PORT, () => console.log('MiniGram on port ' + PORT));
