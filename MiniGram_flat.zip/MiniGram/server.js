const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000;
const ADMIN = process.env.ADMIN_PASSWORD || 'admin123'; // ПОМЕНЯЙ через переменную ADMIN_PASSWORD
const DB_FILE = path.join(__dirname, 'data.json');
let db = { users: {}, msgs: [], groups: [], sessions: {}, nextId: 1 };
try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE))); } catch {}
let timer;
const save = () => { clearTimeout(timer); timer = setTimeout(() => fs.writeFile(DB_FILE, JSON.stringify(db), () => {}), 500); };
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString('hex');
const json = (res, c, o) => { res.writeHead(c, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
const body = req => new Promise(r => { let b = ''; req.on('data', d => { b += d; if (b.length > 1e5) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(b || '{}')); } catch { r({}); } }); });
const NAME = /^[a-zA-Z0-9_]{3,20}$/;
const files = { '/': 'index.html', '/admin': 'admin.html', '/manifest.json': 'manifest.json' };
const online = new Map(); // ws -> name
const send = (ws, o) => ws.readyState === 1 && ws.send(JSON.stringify(o));
const broadcast = o => { for (const w of online.keys()) send(w, o); };
const canSee = (chat, name) => chat === 'general' || db.groups.some(g => g.id === chat) ||
  (typeof chat === 'string' && chat.startsWith('dm:') && chat.slice(3).split('|').includes(name));
const kick = name => { for (const [w, n] of online) if (n === name) { send(w, { t: 'kick' }); w.close(); } };

const server = http.createServer(async (req, res) => {
  const u = req.url.split('?')[0];
  if (req.method === 'GET' && files[u]) {
    const f = path.join(__dirname, files[u]);
    res.writeHead(200, { 'Content-Type': f.endsWith('.json') ? 'application/json' : 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(f));
  }
  if (u.startsWith('/api/admin/')) {
    if (req.headers['x-admin'] !== ADMIN) return json(res, 401, { error: 'Неверный пароль админа' });
    if (u === '/api/admin/stats') return json(res, 200, { users: Object.keys(db.users).length, msgs: db.msgs.length, groups: db.groups.length, online: new Set(online.values()).size });
    if (u === '/api/admin/users') return json(res, 200, Object.entries(db.users).map(([name, x]) => ({ name, created: x.created, banned: x.banned, online: [...online.values()].includes(name) })));
    if (u === '/api/admin/msgs') return json(res, 200, db.msgs.slice(-100).reverse());
    if (u === '/api/admin/ban') { const { name, banned } = await body(req); if (!db.users[name]) return json(res, 404, {}); db.users[name].banned = !!banned; save(); if (banned) kick(name); return json(res, 200, { ok: 1 }); }
    if (u === '/api/admin/delmsg') { const { id } = await body(req); db.msgs = db.msgs.filter(m => m.id !== id); save(); broadcast({ t: 'del', id }); return json(res, 200, { ok: 1 }); }
    return json(res, 404, {});
  }
  if (req.method === 'POST' && (u === '/api/register' || u === '/api/login')) {
    const { name, pass } = await body(req);
    if (!NAME.test(name || '') || typeof pass !== 'string' || pass.length < 6) return json(res, 400, { error: 'Имя: 3-20 символов (a-z, 0-9, _). Пароль: от 6' });
    if (u === '/api/register') {
      if (db.users[name]) return json(res, 400, { error: 'Имя занято' });
      const salt = crypto.randomBytes(8).toString('hex');
      db.users[name] = { salt, hash: hash(pass, salt), created: Date.now(), banned: false };
      save(); broadcast({ t: 'user', name });
    }
    const usr = db.users[name];
    if (!usr || usr.hash !== hash(pass, usr.salt)) return json(res, 401, { error: 'Неверное имя или пароль' });
    if (usr.banned) return json(res, 403, { error: 'Аккаунт заблокирован' });
    const token = crypto.randomBytes(24).toString('hex');
    db.sessions[token] = name; save();
    return json(res, 200, { token, name });
  }
  json(res, 404, { error: 'not found' });
});

const wss = new WebSocketServer({ server });
wss.on('connection', ws => {
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'auth') {
      const n = db.sessions[m.token], usr = db.users[n];
      if (!usr || usr.banned) { send(ws, { t: 'kick' }); return ws.close(); }
      online.set(ws, n);
      return send(ws, { t: 'init', me: n, groups: db.groups, users: Object.keys(db.users) });
    }
    const me = online.get(ws);
    if (!me) return;
    if (db.users[me].banned) { send(ws, { t: 'kick' }); return ws.close(); }
    if (m.t === 'hist' && canSee(m.chat, me)) return send(ws, { t: 'hist', chat: m.chat, msgs: db.msgs.filter(x => x.chat === m.chat).slice(-50) });
    if (m.t === 'msg' && canSee(m.chat, me) && typeof m.text === 'string' && m.text.trim()) {
      const msg = { id: db.nextId++, chat: m.chat, from: me, text: m.text.slice(0, 2000), ts: Date.now() };
      db.msgs.push(msg); if (db.msgs.length > 5000) db.msgs.shift(); save();
      for (const [w, n] of online) if (canSee(m.chat, n)) send(w, { t: 'msg', msg });
    }
    if (m.t === 'newgroup' && typeof m.name === 'string' && m.name.trim()) {
      const g = { id: 'g:' + db.nextId++, name: m.name.trim().slice(0, 30), owner: me };
      db.groups.push(g); save(); broadcast({ t: 'group', g });
    }
  });
  ws.on('close', () => online.delete(ws));
});
server.listen(PORT, () => console.log('MiniGram on port ' + PORT));
